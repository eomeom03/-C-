#include <stdio.h>
int main() 
{
		printf("Hello world \n");
		printf("age = %d \n", 21);
		printf("student ID number = %d \n", 202303786);
		printf("birthday = %d, %d, %d \n", 2003, 6, 7);
	return 0;
}
