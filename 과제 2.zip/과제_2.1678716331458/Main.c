#include <stdio.h>
int main() {
	float c = 36.5;
	float f = c * 9 / 5 + 32;
		printf("섭씨 %.2f도는 화씨 %.2f도와 같습니다", c, f);
	return 0;
}
