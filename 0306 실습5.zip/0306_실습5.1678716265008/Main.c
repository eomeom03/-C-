#include <stdio.h>
int main() 
{
	int num1 = 5;
	int num2 = 7;
	int total = 0;
	
	total = num1 + num2;
	
	printf("%d + %d = %d", num1, num2, total);
	
	return 0;
}
