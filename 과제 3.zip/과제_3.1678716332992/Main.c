#include <stdio.h>
int main() {
	int x = 20;
	int y = 3;
	printf("%d / %d 의 몫 : %d \n", x, y, x/y);
	printf("%d / %d 의 나머지 : %d \n", x, y, x-x/y*y);
	
	return 0;
}
