#include <stdio.h>
int main() {
	printf("5 x 1 = 5 \n");
	printf("5 x 2 = 10 \n");
	printf("5 x 3 = 15 \n");
	printf("5 x 4 = 20 \n");
	printf("5 x 5 = 25 \n");
	printf("5 x 6 = 30 \n");
	printf("5 x 7 = 35 \n");
	printf("5 x 8 = 40 \n");
	printf("5 x 9 = 45 \n");
	return 0;
}
